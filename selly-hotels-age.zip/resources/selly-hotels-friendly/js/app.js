var titleText = 'Привет, мой друг! Добро пожаловать на сайт группы отелей Selly Hotels!';

var promoTitle = document.getElementById('promoTitle'); // получаем заголовок страницы
promoTitle.innerText = titleText;                       // заменяем текст в заголовке

var visitorAge = prompt('Сколько вам лет?');
var promoWrapper = document.getElementById('promoWrapper');

if (visitorAge !== null && visitorAge.trim() !== '') {
    var age = Number(visitorAge);

    if (Number.isFinite(age) && age >= 0) {
        if (age < 16) {
            promoWrapper.classList.add('aquapark');
        } else if (age <= 35) {
            promoWrapper.classList.add('club');
        }
    }
}
