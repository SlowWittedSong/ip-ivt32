var titleText = 'Привет, мой друг! Добро пожаловать на сайт группы отелей Selly Hotels!';

var promoTitle = document.getElementById('promoTitle'); // получаем заголовок страницы
promoTitle.innerText = titleText;                       // заменяем текст в заголовке

var showAllFeedbacks = document.getElementById('showAllFeedbacks');
var hiddenFeedbacks = document.getElementById('hiddenFeedbacks');

showAllFeedbacks.addEventListener('click', function() {
    hiddenFeedbacks.classList.remove('hidden');
    hiddenFeedbacks.classList.add('visible');
    showAllFeedbacks.style.display = 'none';
});
