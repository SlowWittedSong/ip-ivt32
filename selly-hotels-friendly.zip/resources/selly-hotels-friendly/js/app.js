var visitorName = prompt('Как к вам обращаться?');

if (visitorName !== null && visitorName.trim() !== '') {
    visitorName = visitorName.trim();
} else {
    visitorName = 'мой друг';
}

var titleText = 'Привет, ' + visitorName + '! Добро пожаловать на сайт группы отелей Selly Hotels!';

var promoTitle = document.getElementById('promoTitle'); // получаем заголовок страницы
promoTitle.innerText = titleText;                       // заменяем текст в заголовке